Lonely Ruins
------------
By Kableado (VAR)

You are a robot on a rescue mision.
The rescuer and the rescued are alone
in a strange place.

Good Luck!





Controls:
---------
Cursors to move.



CopyRight (C) 2011-2012 Valeriano Alfonso Rodriguez
http://varstudio.net
